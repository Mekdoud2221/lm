import { Request, Response } from "express";
import Task from "../models/TaskModel";
import Project from "../models/ProjectModel";

// Créer une tâche
export const createTask = async (req: Request, res: Response) => {
  try {
    const { projectId } = req.body;

    // Vérifier si le projet existe
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(400).json({ message: "Le projet n'existe pas" });
    }

    const task = await Task.create(req.body);
    res.status(201).json(task);
  } catch (err) {
    res.status(500).json({ message: "Erreur lors de la création de la tâche", error: err });
  }
};

// Lister toutes les tâches (avec ou sans filtre par projectId)
export const getTasks = async (req: Request, res: Response) => {
  try {
    const { projectId } = req.query;

    const filter: any = projectId ? { projectId } : {};

    // Peupler la référence du projet dans les résultats
    const tasks = await Task.find(filter).populate("projectId", "name description");
    res.status(200).json(tasks);
  } catch (err) {
    res.status(500).json({ message: "Erreur lors de la récupération des tâches", error: err });
  }
};

// Récupérer une tâche par son ID
export const getTaskById = async (req: Request, res: Response) => {
  try {
    const task = await Task.findById(req.params.id).populate("projectId", "name description");
    if (!task) {
      return res.status(404).json({ message: "Tâche non trouvée" });
    }
    res.status(200).json(task);
  } catch (err) {
    res.status(500).json({ message: "Erreur lors de la récupération de la tâche", error: err });
  }
};

// Mettre à jour une tâche
export const updateTask = async (req: Request, res: Response) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!task) {
      return res.status(404).json({ message: "Tâche non trouvée" });
    }
    res.status(200).json(task);
  } catch (err) {
    res.status(500).json({ message: "Erreur lors de la mise à jour de la tâche", error: err });
  }
};

// Supprimer une tâche
export const deleteTask = async (req: Request, res: Response) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) {
      return res.status(404).json({ message: "Tâche non trouvée" });
    }
    res.status(200).json({ message: "Tâche supprimée avec succès" });
  } catch (err) {
    res.status(500).json({ message: "Erreur lors de la suppression de la tâche", error: err });
  }
};

// Marquer une tâche comme terminée
export const markTaskDone = async (req: Request, res: Response) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, { done: true }, { new: true });
    if (!task) {
      return res.status(404).json({ message: "Tâche non trouvée" });
    }
    res.status(200).json(task);
  } catch (err) {
    res.status(500).json({ message: "Erreur lors de la mise à jour de la tâche", error: err });
  }
};

// Filtrer les tâches avec une échéance avant une date donnée
export const getTasksDueBefore = async (req: Request, res: Response) => {
  try {
    const { date } = req.query;

    if (!date || isNaN(Date.parse(date as string))) {
      return res.status(400).json({ message: "Format de date invalide, utilisez YYYY-MM-DD" });
    }

    const tasks = await Task.find({
      dueDate: { $lt: new Date(date as string) }
    }).populate("projectId", "name description");

    res.status(200).json(tasks);
  } catch (err) {
    res.status(500).json({ message: "Erreur lors du filtrage des tâches", error: err });
  }
};
