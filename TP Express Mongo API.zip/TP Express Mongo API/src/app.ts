import express, { Application, Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import projectRouter from './routes/projectRoutes';
import taskRouter from './routes/taskRoutes';

// Charger les variables d'environnement
dotenv.config();

// Initialiser l'application Express
const app: Application = express();

// Middleware globaux
app.use(express.json()); // Pour parser le JSON dans les requêtes

// Gestion des erreurs et logs simples
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error(err.message || 'Erreur serveur');
  res.status(err.status || 500).json({ error: err.message || 'Erreur serveur' });
});

// Routes
app.use('/projects', projectRouter); // Routes pour les projets
app.use('/tasks', taskRouter); // Routes pour les tâches

// Route par défaut (404 Not Found)
app.use((req: Request, res: Response) => {
  res.status(404).json({ message: 'Route non trouvée' });
});

// Connexion à MongoDB et démarrage du serveur
const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/your-database-name';

mongoose
  .connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true } as mongoose.ConnectOptions)
  .then(() => {
    console.log('Connecté à MongoDB avec succès');
    app.listen(PORT, () => console.log(`Serveur démarré sur le port ${PORT}`));
  })
  .catch((error) => {
    console.error('Erreur lors de la connexion à MongoDB :', error.message);
    process.exit(1); // Arrêter l'application si la connexion échoue
  });

export default app;
