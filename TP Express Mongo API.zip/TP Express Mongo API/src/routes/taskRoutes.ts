import { Router } from "express";
import {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
  markTaskDone,
  getTasksDueBefore
} from "../controllers/taskController";

const router = Router();

// Routes principales
router.post("/", createTask);
router.get("/", getTasks);
router.get("/:id", getTaskById);
router.put("/:id", updateTask);
router.delete("/:id", deleteTask);

// Routes spécifiques
router.post("/:id/mark-done", markTaskDone);
router.get("/due-before", getTasksDueBefore);

export default router;

